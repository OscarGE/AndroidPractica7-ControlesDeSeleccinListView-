package com.example.practica6_controlesdeseleccinlistview

class Producto (val nombre:String, val precio: Double, val descripcion: String, val imagen: Int)